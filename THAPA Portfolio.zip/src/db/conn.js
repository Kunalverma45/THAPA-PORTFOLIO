const mongoose = require("mongoose");

// creating a DATABASE
mongoose.connect("mongodb://localhost:27017/Kunaldynamic",{
    // useCreateIndex:true,
    // useNewUrlParse:true,
    // useUnifiedTopology:true
}).then(()=>{
    console.log("connection Succesfully done...")
}).catch((error) =>{
    console.log(error);
})