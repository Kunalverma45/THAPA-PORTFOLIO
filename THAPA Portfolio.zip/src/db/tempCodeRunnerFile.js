const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

// routing 
// app.get(path, callback)
app.get("/",(req,res)=>{
    res.send("hello Guys, My name is Kunal Verma.")
})

//server create 
app.listen(port,()=>{
    console.log(`Server is running at port no ${port}`);
})